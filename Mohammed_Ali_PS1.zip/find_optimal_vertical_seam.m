function verticalSeam = find_optimal_vertical_seam(cumulativeEnergyMap)
%vertical seam is a 1 by M vector where M is the number of rows in
%the image. First, the min of the last row is stored in the
%last element of verticalSeam vector.
%Then the for loop begins from the second last row and works towards the first row
%of the image. 
[rows, cols] = size(cumulativeEnergyMap);
verticalSeam = zeros(1,rows);
lastRow = cumulativeEnergyMap(rows,:);
[M,previousPixel] = min(lastRow);
currentPixel = previousPixel;
verticalSeam(rows) = currentPixel;

for i = rows-1:-1:1
    j = previousPixel;
    if previousPixel == 1
        [M,pixel] = min([cumulativeEnergyMap(i,j),cumulativeEnergyMap(i,j+1)]);
        if pixel == 2
            currentPixel = previousPixel+1;
        else
            currentPixel = previousPixel;
        end
    elseif previousPixel == cols
        [M,pixel] = min([cumulativeEnergyMap(i,j-1),cumulativeEnergyMap(i,j)]);
        if pixel == 1
            currentPixel = previousPixel-1; 
        else
            currentPixel = previousPixel;
        end
    else
        [M,pixel] = min([cumulativeEnergyMap(i,j-1),cumulativeEnergyMap(i,j), cumulativeEnergyMap(i,j+1)]);
        if pixel == 1
            currentPixel = previousPixel-1;
        elseif pixel == 2
            currentPixel = previousPixel;
        else
            currentPixel = previousPixel+1;
        end
    end
    verticalSeam(i) = currentPixel;
    previousPixel = currentPixel;
end


end

