function [reducedColorImage,reducedEnergyImage] = reduce_height(im,energyImage)
%UNTITLED10 Summary of this function goes here
%   Detailed explanation goes here
cuMinMap = cumulative_minimum_energy_map(energyImage,'HORIZONTAL');
optimalHoriSeam = find_optimal_horizontal_seam(cuMinMap);
[rows,cols,color] = size(im);

for i=1:cols
    temp = im(:,i,1);
    del = optimalHoriSeam(i);
    temp(del) = [];
    reducedColorImage(:,i,1) = temp; 
    
    temp = im(:,i,2);
    temp(del) = [];
    reducedColorImage(:,i,2) = temp; 
    
    temp = im(:,i,3);
    temp(del) = [];
    reducedColorImage(:,i,3) = temp;
end

reducedEI = energy_image(reducedColorImage);
reducedEnergyImage = im2double(reducedEI);

end

