function energyImage = energy_image(im)
%Coverts image to grayscale then calculates energy of image using
%imgradient(). Then converts the energy image to double before returning.
imGray = rgb2gray(im);
[Gmag, Gdir] = imgradient(imGray, 'roberts');

energyImage = im2double(Gmag);

end

