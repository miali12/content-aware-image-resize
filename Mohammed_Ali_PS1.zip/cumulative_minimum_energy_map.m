function cumulativeEnergyMap = cumulative_minimum_energy_map(energyImage,seamDirection)
%This function takes in an image of type double and checks 
%if a vertical or horizontal cumulative enerygy map is required.
%depending on the seamDirection, a cumulative enerygy map is produced
%using the cumulative minimum eneryg equation.  
[rows,cols] = size(energyImage); 
M = energyImage;

if strcmp(seamDirection, 'VERTICAL')
    for i=2:rows
        previousRow = M(i-1,:);
        minMatrix(1,:) = previousRow;
        minMatrix(2,:) = previousRow;
        minMatrix(3,:) = previousRow;
        
        minMatrix(2,:) = circshift(minMatrix(2,:),1);
        minMatrix(3,:) = circshift(minMatrix(3,:),cols-1);
        
        minMatrix(2,1) = inf;
        minMatrix(3,cols) = inf;
        
        minVector = min(minMatrix);
        M(i,:) = energyImage(i,:) + minVector; 
    end
elseif strcmp(seamDirection, 'HORIZONTAL')
    rotatedIm = imrotate(energyImage, -90);
    [rows,cols] = size(rotatedIm);
    M = rotatedIm;
    for i=2:rows
        previousRow = M(i-1,:);
        minMatrix(1,:) = previousRow;
        minMatrix(2,:) = previousRow;
        minMatrix(3,:) = previousRow;
        
        minMatrix(2,:) = circshift(minMatrix(2,:),1);
        minMatrix(3,:) = circshift(minMatrix(3,:),cols-1);
        
        minMatrix(2,1) = inf;
        minMatrix(3,cols) = inf;
        
        minVector = min(minMatrix);
        M(i,:) = rotatedIm(i,:) + minVector;
    end
    M = imrotate(M,90);
end

cumulativeEnergyMap = im2double(M);


end