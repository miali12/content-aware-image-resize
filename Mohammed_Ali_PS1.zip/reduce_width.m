function [reducedColorImage,reducedEnergyImage] = reduce_width(im,energyImage)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
cuMinMap = cumulative_minimum_energy_map(energyImage,'VERTICAL');
optimalVertSeam = find_optimal_vertical_seam(cuMinMap);
[rows,cols,color] = size(im);

for i=1:rows
    reducedColorImage(i,:,1) = im(i,[1:optimalVertSeam(i)-1,optimalVertSeam(i)+1:end],1);
    reducedColorImage(i,:,2) = im(i,[1:optimalVertSeam(i)-1,optimalVertSeam(i)+1:end],2);
    reducedColorImage(i,:,3) = im(i,[1:optimalVertSeam(i)-1,optimalVertSeam(i)+1:end],3);
end

reducedEI = energy_image(reducedColorImage);
reducedEnergyImage = im2double(reducedEI);

end

