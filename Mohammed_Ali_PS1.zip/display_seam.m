function display_seam(im,seam,seamDirection)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
[rows, cols, color] = size(im);
imshow(im);
hold on;
if strcmp(seamDirection,'VERTICAL')
    Y = 1:rows;
    plot(seam,Y)
    set(gca,'XAxisLocation','top','YAxisLocation','left','ydir','reverse');
elseif strcmp(seamDirection ,'HORIZONTAL')
    plot(seam)
end

end

