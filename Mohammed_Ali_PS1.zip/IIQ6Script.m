clc;
clear;

match = imread('match.jpg');
shoes = imread('boots.jpg');
ten = imread('ten.jpg');

matchEnergy = energy_image(match);
res1 = match;

 for i =1:100
     [match,matchEnergy] = reduce_width(match,matchEnergy);
     res1 = match;
 end
 match = imread('match.jpg');
 [rows, cols, colors] = size(res1);
 matchMatResized = imresize(match,[rows cols]);
 
 
 subplot(1,3,1), imshow(match); title('original image');
 subplot(1,3,2), imshow(res1); title('seam carving resize');
 subplot(1,3,3), imshow(matchMatResized); title('matlab resize');

 shoesEnergy = energy_image(shoes);
 res2 = shoes;
 
 for i =1:50
      [shoes,shoesEnergy] = reduce_height(shoes,shoesEnergy);
      [shoes,shoesEnergy] = reduce_width(shoes,shoesEnergy);
      res2 = shoes;
 end
 shoes = imread('boots.jpg');
[rows, cols, colors] = size(res2);
 shoesMatResized = imresize(shoes,[rows cols]);
  
 figure; 
 subplot(1,3,1), imshow(shoes); title('original image');
 subplot(1,3,2), imshow(res2); title('seam carving resize');
 subplot(1,3,3), imshow(shoesMatResized); title('matlab resize');


tenEnergy = energy_image(ten);
res3 = ten;

for i =1:100
     [ten,tenEnergy] = reduce_height(ten,tenEnergy);
     res3 = ten;
end
ten = imread('ten.jpg');
[rows, cols, colors] = size(res3);
tenMatResized = imresize(ten,[rows cols]);
 
figure; 
subplot(1,3,1), imshow(ten); title('original image');
subplot(1,3,2), imshow(res3); title('seam carving resize');
subplot(1,3,3), imshow(tenMatResized); title('matlab resize');


