function  horizontalSeam = find_optimal_horizontal_seam(cumulativeEnergyMap)
%Analagous to find_optimal_vertical_seam.
[rows, cols] = size(cumulativeEnergyMap);
horizontalSeam = zeros(1,cols);
lastCol = cumulativeEnergyMap(:,cols);
[M,previousPixel] = min(lastCol);
currentPixel = previousPixel;
horizontalSeam(cols) = currentPixel;

for i = cols-1:-1:1
    j = previousPixel;
    if previousPixel == 1
        [M,pixel] = min([cumulativeEnergyMap(j, i),cumulativeEnergyMap(j+1,i)]);
        if pixel == 2
            currentPixel = previousPixel+1;
        else
            currentPixel = previousPixel;
        end
    elseif previousPixel == rows
        [M,pixel] = min([cumulativeEnergyMap(j-1,i),cumulativeEnergyMap(j,i)]);
        if pixel == 1
            currentPixel = previousPixel-1;
        else
            currentPixel = previousPixel;
        end
    else
        [M,pixel] = min([cumulativeEnergyMap(j-1,i),cumulativeEnergyMap(j,i), cumulativeEnergyMap(j+1,i)]);
        if pixel == 1
            currentPixel = previousPixel-1;
        elseif pixel == 2
            currentPixel = previousPixel;
        else
            currentPixel = previousPixel+1;
        end
    end
    horizontalSeam(i) = currentPixel;
    previousPixel = currentPixel;
end

end

