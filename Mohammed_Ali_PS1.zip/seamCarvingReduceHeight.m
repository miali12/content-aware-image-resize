clc;
clear;

prague = imread('inputSeamCarvingPrague.jpg');
pragueEnergy = energy_image(prague);
res1 = prague;

for i =1:50
    [prague,pragueEnergy] = reduce_height(prague,pragueEnergy);
    res1 = prague;
end
imshow(res1);

mall = imread('inputSeamCarvingMall.jpg');
mallEnergy = energy_image(mall);
res2 = mall;

for i =1:50
    [mall,mallEnergy] = reduce_height(mall,mallEnergy);
    res2 = mall;
end
figure;
imshow(res2);
